public class Main {
    public static void main(String[] args) {
        //1.
        int a;
        System.out.println(a =89);
        byte b;
        System.out.println(b =4);
        short c;
        System.out.println(c =56);
        float x = 4.7333436F;
        System.out.println(x);
        double y = 4.355453532;
        System.out.println(y);
        long z =12121;
        System.out.println(z);
        char ch='G';
        System.out.println(ch);
        System.out.println();

        //2.
        System.out.print(3);
        System.out.print(4);
        System.out.print(5);


    }
}